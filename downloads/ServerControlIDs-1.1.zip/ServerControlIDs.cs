#region Licence
// Copyright (c) 2008 James Gregory (james@jagregory.com)
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
// 
//     * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//     * Neither the name of James Gregory nor the names of its
//     contributors may be used to endorse or promote products derived from this
//     software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
// THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#endregion

using System;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JAGregory
{
	/// <summary>
	/// Outputs a JavaScript object that contains a collection of control IDs and ClientIDs
	/// mapped together.
	/// </summary>
	/// <remarks>
	///		Created by James Gregory, 2006.
	///		Website: http://www.jagregory.com
	///		ServerControlIDs Home: http://blog.jagregory.com/pages/ServerControlIDs
	///	</remarks>
	/// <example>
	///		Within a page's PreRender event.
	///		
	///			ServerControlIDs scIDs = new ServerControlIDs();
	///		
	///			scIDs.Emit(this, clientIDs);
	///			
	///		Within the pages ASPX
	///		
	///			<head>
	///				...
	///				<asp:Literal ID="clientIDs" Runat="server" />
	///			</head>
	/// </example>
	public class ServerControlIDs
	{
		private bool whitespace = true;
		private string variableName = "ClientIDs";

		/// <summary>
		/// Builds a list of paired control IDs and client IDs, then emits them into
		/// a script block.
		/// </summary>
		/// <param name="page">The page to emit into and build the controls from.</param>
		public void Emit(Page page)
		{
			Emit(page, null);
		}

		/// <summary>
		/// Builds a list of paired control IDs and client IDs, then emits them into
		/// the supplied literal control; or the control if it is a page.
		/// </summary>
		/// <remarks>
		/// The literal control (target) would ideally be placed in the <head> tag to
		/// provide structurally correct markup.
		/// </remarks>
		/// <param name="page">The page to emit to if the target is null, and build the
		/// controls from.</param>
		/// <param name="target">Literal control to output the script block into.</param>
		public void Emit(Control control, Literal target)
		{
			string[] maps = this.GetMappedIDs(control);
			StringBuilder sb = new StringBuilder();

			sb.Append("<script type=\"text/javascript\">");
			if (whitespace) sb.Append("\n\t\t");

			if (whitespace)
				sb.AppendFormat("var {0} = {{", variableName);
			else
				sb.AppendFormat("var {0}={{", variableName);

			foreach (string map in maps)
			{
				if (whitespace) sb.Append("\n\t\t\t");
				sb.Append(map);

				if (Array.IndexOf(maps, map) < (maps.Length - 1)) sb.Append(',');
			}

			if (whitespace) sb.Append("\n\t\t");
			sb.Append("}");
			if (whitespace) sb.Append("\n\t");
			sb.Append("</script>");

			if (target != null)
				target.Text = sb.ToString();
			else if (control is Page)
				((Page)control).RegisterClientScriptBlock(variableName, sb.ToString());
		}

		/// <summary>
		/// Builds an array of paired IDs.
		/// </summary>
		/// <remarks>
		/// Format: ExpectedID:'ActualID'
		/// e.g. News: '_ctrl0:News'
		/// </remarks>
		/// <param name="control">The control to build the pairs from.</param>
		/// <returns>String array of paired IDs.</returns>
		private string[] GetMappedIDs(Control control)
		{
			ArrayList mappings = new ArrayList();
			string format = (whitespace) ? "{0}: '{1}'" : "{0}:'{1}'";

			foreach (Control ctrl in control.Controls)
			{
				// this needs cleaning up; checks for controls that shouldn't be output
				if (ctrl.ClientID != null && ctrl.ID != null && ctrl.Visible &&
					(!(ctrl is PlaceHolder) && !(ctrl is Literal) && !(ctrl is DataGrid) && !(ctrl is Repeater) && !(ctrl is DataList)))
				{
					mappings.Add(string.Format(format, ctrl.ID, ctrl.ClientID));
				}

				// add sub-controls, only if not a repeatable control (otherwise we'd get duplicate references)
				if (ctrl.HasControls() && (!(ctrl is DataGrid) && !(ctrl is Repeater) && !(ctrl is DataList)))
					mappings.AddRange(this.GetMappedIDs(ctrl));
			}

			return (string[])mappings.ToArray(typeof(string));
		}

		public bool Whitespace
		{
			get { return whitespace; }
			set { whitespace = value; }
		}

		public string VariableName
		{
			get { return variableName; }
			set { variableName = value; }
		}
	}
}
